#include <stdio.h>
int main (int N, char *P[])
{
printf("Je suis le code ARM !\n");
return 0;
}

